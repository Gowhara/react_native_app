// store/index.js
import { configureStore } from '@reduxjs/toolkit';
import todosReducer from './todoSlice';

const completedTodosReducer = (state = [], action) => {
  switch (action.type) {
    case 'todos/completeTodo':
      return [...state, action.payload];
    default:
      return state;
  }
};

export const store = configureStore({
  reducer: {
    todos: todosReducer,
    completedTodos: completedTodosReducer,
  },
});
