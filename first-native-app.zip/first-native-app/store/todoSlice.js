// store/todosSlice.js
import { createSlice } from '@reduxjs/toolkit';

const todosSlice = createSlice({
  name: 'todos',
  initialState: {
    todos: [],
    completedTodos: []
  },
  reducers: {
    addTodo: (state, action) => {
      state.todos.push(action.payload);
    },
    completeTodo: (state, action) => {
      const { id } = action.payload;
      const index = state.todos.findIndex(todo => todo.id === id);
      if (index !== -1) {
        const completedTodo = state.todos.splice(index, 1)[0];
        state.completedTodos.push(completedTodo);
      }
    },
  },
});

export const { addTodo, completeTodo } = todosSlice.actions;

export default todosSlice.reducer;
