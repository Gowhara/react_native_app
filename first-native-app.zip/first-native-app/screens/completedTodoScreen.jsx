// screens/CompletedTodosScreen.js
import React from 'react';
import { View, Text, FlatList } from 'react-native';
import { useSelector } from 'react-redux';

const CompletedTodosScreen = () => {
  const completedTodos = useSelector(state => state.todos.completedTodos); // Access completedTodos from Redux store

  return (
    <View>
      <Text>Completed Todos</Text>
      <FlatList
        data={completedTodos}
        renderItem={({ item }) => (
          <View>
            <Text>{item.title}</Text>
            <Text>{item.description}</Text>
          </View>
        )}
        keyExtractor={(item, index) => index.toString()}
      />
    </View>
  );
};

export default CompletedTodosScreen;
