import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, Dimensions, Alert } from "react-native";

const TodoDetailsScreen = ({ route }) => {
  const { todo } = route.params;
  const [orientation, setOrientation] = useState("");

  useEffect(() => {
    const updateOrientation = () => {
      const windowDimensions = Dimensions.get("window");
      const newOrientation = windowDimensions.width > windowDimensions.height ? "landscape" : "portrait";
      setOrientation(newOrientation);
      /*Alert.alert("Orientation Changed", `New Orientation: ${newOrientation}`);*/
    };

    Dimensions.addEventListener("change", updateOrientation);

    return () => {
      Dimensions.removeEventListener("change", updateOrientation);
    };
  }, []);

  return (
    <View style={[styles.container, orientation === "landscape" && styles.landscapeContainer]}>
      <Text style={styles.centerText}>Todo Detail</Text>
      <Text style={styles.text}>{todo.title}</Text>
      <Text style={styles.text}>{todo.description}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    justifyContent: "center",
  },
  centerText: {
    textAlign: "center",
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  text: {
    fontSize: 24,
    textAlign: "center",
  },
  landscapeContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
  },
});

export default TodoDetailsScreen;
