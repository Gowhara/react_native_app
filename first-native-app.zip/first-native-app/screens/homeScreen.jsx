
import React from 'react';
import { View, Text, Button, TextInput, FlatList,StyleSheet,TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { useDispatch, useSelector } from 'react-redux';
import { addTodo, completeTodo } from '../store/todoSlice'; // Import completeTodo action
import { useNavigation } from '@react-navigation/native'; // Import useNavigation hook

const homeScreen = () => {
  const [title, setTitle] = React.useState('');
  const [description, setDescription] = React.useState('');
  const todos = useSelector(state => state.todos.todos); // Access todos from Redux store
  const dispatch = useDispatch();
  const navigation = useNavigation(); // Initialize useNavigation hook

  const handleAddTodo = () => {
    if (!title || !description) return;
    dispatch(addTodo({
      id: Math.random().toString(36).substr(2, 9),
      title,
      description,
      completed: false
    }));
    setTitle('');
    setDescription('');
  };

  const handleCompleteTodo = (todo) => { 
    dispatch(completeTodo(todo)); 
  };


  
  const DeleteButton = ({ onDelete }) => {
    return (
      <TouchableOpacity onPress={onDelete}>
        <Icon name="trash-o" size={18} color="black" />
      </TouchableOpacity>
    );
  }

  const handleDeleteItem = (id) => {
    setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== id));
  };

  
  return (
    <View style={styles.container}>
      <Text style={styles.centerText}>TODO APP</Text>
      <TextInput style={styles.input}
        placeholder="Title"
        value={title}
        onChangeText={setTitle}
      />
      <TextInput style={styles.input}
        placeholder="Description"
        value={description}
        onChangeText={setDescription}
      />
     
      <TouchableOpacity onPress={handleAddTodo}>
          <View style={styles.button}>
            <Text style={styles.buttonText}>Add</Text>
          </View>
        </TouchableOpacity>
      <FlatList
        data={todos}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text style={styles.title}>{item.title}</Text>
            <Text>{item.description}
               {!item.completed && <Icon name="check" onPress={() => handleCompleteTodo(item)} />}    
               <DeleteButton onDelete={() => handleDeleteItem(item.id)} />
             
               </Text>
                
          </View>
        )}
        keyExtractor={(item, index) => index.toString()}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  checkButton: {
    margin: 10,
  },
  container: {
    flex: 1,
    backgroundColor: "#fff",
    justifyContent: "center",
  },
  centerText: {
    textAlign: "center",
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
  button: {
    marginBottom: 30,
    width: 330,
    alignItems: "center",
    backgroundColor: "#483d8b",
    marginLeft: 10,
  },
  buttonText: {
    textAlign: "center",
    padding: 10,
    color: "white",
  },
  item: {
    backgroundColor: "#f9c2ff",
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  title: {
    fontSize: 25,
  },
});


export default homeScreen;
